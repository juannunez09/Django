from django.apps import AppConfig


class HelloWorldConfig(AppConfig):
    name = 'hello_world'
